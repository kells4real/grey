from django.contrib import admin
from .models import *
# Register your models here.


admin.site.register(Portfolio)
admin.site.register(Investment)
admin.site.register(Profit)
admin.site.register(SoldInvestment)


