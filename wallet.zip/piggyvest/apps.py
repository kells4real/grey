from django.apps import AppConfig


class PiggyvestConfig(AppConfig):
    name = 'piggyvest'
