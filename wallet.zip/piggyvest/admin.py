from django.contrib import admin
from .models import Piggy


admin.site.register(Piggy)
