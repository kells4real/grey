## KHUB Backend

#### Clone or download the project,set up an environment, and install the required packages from the requirements.txt file

### Run Project
#### CD into the project, run the command
```
python manage.py runserver
```
#### This would run the application on a default port 8000
