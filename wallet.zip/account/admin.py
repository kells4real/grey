from django.contrib import admin
from .models import BankAccount
# Register your models here.

admin.site.register(BankAccount)